package com.important;
import java.util.ArrayList;
import java.util.List;
class Player {
    private String name;
    private List<Strategy> chosenStrategies = new ArrayList<>();

    public Player(String name) {
        this.name = name;
    }

    public void chooseStrategy(Strategy strategy) {
        chosenStrategies.add(strategy);
    }

    public List<Strategy> getChosenStrategies() {
        return chosenStrategies;
    }

    public String getName() {
        return name;
    }
}