package com.important;

import java.util.HashMap;
import java.util.Map;

class Strategy {
    private int id;
    private String name;

    public Strategy(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
}


