package com.important;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Strategy> allStrategies = new ArrayList<>();
        allStrategies.add(new Strategy(1, "LowPriceStrategy"));
        allStrategies.add(new Strategy(2, "HighQualityStrategy"));
        allStrategies.add(new Strategy(3, "PromotionalStrategy"));
        allStrategies.add(new Strategy(4, "DiscountStrategy"));
        allStrategies.add(new Strategy(5, "BundleOfferStrategy"));
        allStrategies.add(new Strategy(6, "ExclusiveOfferStrategy"));

        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");

        System.out.println("Available strategies for Player 1:");
        for (Strategy strategy : allStrategies) {
            System.out.println(strategy.getId() + ". " + strategy);
        }

        System.out.println("\nPlayer 1, choose 3 strategies by entering the strategy numbers (e.g., 1 2 3):");
        List<Strategy> player1ChosenStrategies = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            int strategyId = scanner.nextInt();
            Strategy chosenStrategy = findStrategyById(allStrategies, strategyId);
            if (chosenStrategy != null) {
                player1ChosenStrategies.add(chosenStrategy);
                allStrategies.remove(chosenStrategy);
            } else {
                System.out.println("Invalid strategy selection. Please choose again.");
                i--;
            }
        }

        for (Strategy strategy : player1ChosenStrategies) {
            player1.chooseStrategy(strategy);
        }

        System.out.println("\nAvailable strategies for Player 2 (remaining strategies):");
        for (Strategy strategy : allStrategies) {
            System.out.println(strategy.getId() + ". " + strategy);
        }

        System.out.println("\nPlayer 2, choose 3 strategies by entering the strategy numbers (e.g., 4 5 6):");
        List<Strategy> player2ChosenStrategies = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            int strategyId = scanner.nextInt();
            Strategy chosenStrategy = findStrategyById(allStrategies, strategyId);
            if (chosenStrategy != null) {
                player2ChosenStrategies.add(chosenStrategy);
                allStrategies.remove(chosenStrategy);
            } else {
                System.out.println("Invalid strategy selection. Please choose again.");
                i--;
            }
        }

        for (Strategy strategy : player2ChosenStrategies) {
            player2.chooseStrategy(strategy);
        }

        System.out.println("\n" + player1.getName() + " chose strategies:");
        for (Strategy strategy : player1.getChosenStrategies()) {
            System.out.println(strategy);
        }

        System.out.println("\n" + player2.getName() + " chose strategies:");
        for (Strategy strategy : player2.getChosenStrategies()) {
            System.out.println(strategy);
        }

        simulateGame(player1, player2);
    }

    private static Strategy findStrategyById(List<Strategy> strategies, int id) {
        for (Strategy strategy : strategies) {
            if (strategy.getId() == id) {
                return strategy;
            }
        }
        return null;
    }

    private static void simulateGame(Player player1, Player player2) {
        System.out.println("\nSimulating the game...");
        System.out.println(player1.getName() + " strategies:");
        for (Strategy strategy : player1.getChosenStrategies()) {
            System.out.println(strategy);
        }

        System.out.println(player2.getName() + " strategies:");
        for (Strategy strategy : player2.getChosenStrategies()) {
            System.out.println(strategy);
        }

        System.out.println("\nGame Outcome: TBD based on strategy interactions.");
    }
}